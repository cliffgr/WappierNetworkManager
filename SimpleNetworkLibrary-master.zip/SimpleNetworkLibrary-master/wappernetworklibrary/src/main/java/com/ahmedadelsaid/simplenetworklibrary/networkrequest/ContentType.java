package com.ahmedadelsaid.simplenetworklibrary.networkrequest;

/**
 * Created by Ahmed Adel on 19/06/2017.
 *
 * ContentType is an enum class for network request content types.
 *
 */

public enum ContentType {
    JSON,
    XML
}
